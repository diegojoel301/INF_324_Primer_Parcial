﻿
Partial Class testimonial
    Inherits System.Web.UI.Page

End Class
