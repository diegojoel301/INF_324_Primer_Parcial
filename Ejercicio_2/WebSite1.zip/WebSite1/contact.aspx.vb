﻿
Partial Class contact
    Inherits System.Web.UI.Page

End Class
