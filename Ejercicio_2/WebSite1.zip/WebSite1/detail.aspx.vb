﻿
Partial Class detail
    Inherits System.Web.UI.Page

End Class
