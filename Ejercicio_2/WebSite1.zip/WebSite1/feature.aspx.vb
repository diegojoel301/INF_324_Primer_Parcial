﻿
Partial Class feature
    Inherits System.Web.UI.Page

End Class
