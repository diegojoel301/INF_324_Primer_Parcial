﻿
Partial Class team
    Inherits System.Web.UI.Page

End Class
