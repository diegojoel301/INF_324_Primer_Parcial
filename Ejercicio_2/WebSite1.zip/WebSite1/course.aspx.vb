﻿
Partial Class course
    Inherits System.Web.UI.Page

End Class
